package com.example.android.rssfeed;

public class FeedEntry {

	public static String _ID;
	public static String COLUMN_NAME_ENTRY_ID;
	public static String COLUMN_NAME_TITLE;
	public static String TABLE_NAME;

}
