package com.example.android.rssfeed;

import android.app.Activity;


class Holder {

	public static Activity getBase() {
		// TODO Auto-generated method stub
		return null;
	}

}
