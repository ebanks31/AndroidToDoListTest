import junit.framework.TestCase;


public class Rss extends TestCase {

}
